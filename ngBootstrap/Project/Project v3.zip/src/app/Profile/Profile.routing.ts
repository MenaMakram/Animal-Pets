import { Routes, RouterModule } from '@angular/router';
import { ProfileComponent } from './Profile.component';
import { TrainerComponent } from './Trainer/Trainer.component';
import { HomePetsComponent } from './HomePets/HomePets.component';
import { ClientComponent } from './Client/Client.component';
import { AuthGuard } from '../auth/auth.guard';

const routes: Routes = [
  { path: 'Profile', component: ProfileComponent,canActivate: [AuthGuard]},
  {path: 'Trainer', component: ProfileComponent,
children:[{path:'',component:TrainerComponent}]
},
{path: 'HomePets', component: ProfileComponent,
children:[{path:'',component:HomePetsComponent}]
},
{path: 'Client', component: ProfileComponent,
children:[{path:'',component:ClientComponent}]
},
  {path: '', redirectTo: '/', pathMatch: 'full'}
];

export const ProfileRoutes = RouterModule.forChild(routes);
