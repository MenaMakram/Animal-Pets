export class Trainer {
  ID: number;
   JobTitle: string;
   Overview: string;
   Courses: string;
   TrainePlace: string;
   PricePerHour: number;
}
