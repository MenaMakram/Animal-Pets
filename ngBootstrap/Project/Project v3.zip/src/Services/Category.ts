export class Category {
     ID: number ;
      Name: string;
      Image: string ;
}
