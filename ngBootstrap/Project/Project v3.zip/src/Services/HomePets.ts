import {HomePetsPhoto} from './HomePetsPhoto';

export class HomePets {
    Description: string;
    AvailablePlace: number;
    NumberOfRooms: number;
    PriceForNight: number;
    photos: HomePetsPhoto[];
    ID: number;
}
