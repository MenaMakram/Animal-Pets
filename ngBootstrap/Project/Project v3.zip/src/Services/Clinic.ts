export class Clinic {
    ID: number;
    Name: string;
    StartDate: string;
    EndDate: string;
    StartTime: string;
    EndTime: string;
    Phone: string;
    Address: string;
}
