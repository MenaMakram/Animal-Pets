import { Animals } from './Animals';

export class Clients {
    Animals: Animals[];
}
