export class User {
  Id: string;
  FirstName: string;
  LastName: string;
  Address: string;
  Photo: string;
  Phone: string;
  Email: string;
  UserType: number;
}
