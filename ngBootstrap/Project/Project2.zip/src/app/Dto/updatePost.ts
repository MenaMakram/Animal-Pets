export interface UpdatePost {
  ID: number
  Description: string
  UserName: string
  PostDateTime: Date
  postPhotos: string[]
}
