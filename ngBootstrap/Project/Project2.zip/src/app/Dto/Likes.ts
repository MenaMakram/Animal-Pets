export interface Likes {
  postId: number;
  userName: string;
}
