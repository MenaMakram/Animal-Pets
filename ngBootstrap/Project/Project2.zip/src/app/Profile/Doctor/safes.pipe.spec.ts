/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SafesPipe } from './safes.pipe';

describe('Pipe: Safese', () => {
  it('create an instance', () => {
    let pipe = new SafesPipe();
    expect(pipe).toBeTruthy();
  });
});
