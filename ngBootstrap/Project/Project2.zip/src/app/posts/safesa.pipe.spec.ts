/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SafesaPipe } from './safesa.pipe';

describe('Pipe: Safesae', () => {
  it('create an instance', () => {
    let pipe = new SafesaPipe();
    expect(pipe).toBeTruthy();
  });
});
