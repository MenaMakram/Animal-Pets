import { DoctorDetails } from './DoctorDetails';

describe('DoctorDetails', () => {
  it('should create an instance', () => {
    expect(new DoctorDetails()).toBeTruthy();
  });
});
