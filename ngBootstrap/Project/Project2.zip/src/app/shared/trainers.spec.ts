import { Trainers } from './trainers';

describe('Trainers', () => {
  it('should create an instance', () => {
    expect(new Trainers()).toBeTruthy();
  });
});
