import { User } from './user';
export class Trainers {
        public  ID :number
        public  JobTitle :string
        public  Overview :string
        public  Courses :string
        public  TrainePlace :string
        public  PricePerHour :number
        public user:User
}
