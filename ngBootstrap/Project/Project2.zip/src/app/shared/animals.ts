import { User } from './user';

export class Animals {
    public  ID :number
    public  Type :string
    public  Name :string
    public  Gender :string
    public  age :number
    public  Description :string
    public   category :string
    public   AnimalPhotos :string[]
    public user:User
}
