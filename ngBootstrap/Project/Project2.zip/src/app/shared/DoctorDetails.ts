export class DoctorDetails {
    public  ClinicName :string
    public  StartDate :string
    public  EndDate :string
    public  StartTime :string
    public  EndTime :string
    public  ClinicPhone :string
    public  ClinicAddress :string

}

