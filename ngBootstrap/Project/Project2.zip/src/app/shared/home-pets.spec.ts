import { HomePets } from './home-pets';

describe('HomePets', () => {
  it('should create an instance', () => {
    expect(new HomePets()).toBeTruthy();
  });
});
