import { Component, OnInit } from '@angular/core';
import { ViewEncapsulation } from '@angular/compiler/src/core';

@Component({
  selector: 'app-Search',
  templateUrl: './Search.component.html',
  styleUrls: ['./Search.component.css'],
})
export class SearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
