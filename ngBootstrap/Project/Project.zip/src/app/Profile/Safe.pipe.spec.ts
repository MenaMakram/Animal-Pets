/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SafePipe } from './Safe.pipe';

describe('Pipe: Safee', () => {
  it('create an instance', () => {
    let pipe = new SafePipe();
    expect(pipe).toBeTruthy();
  });
});
