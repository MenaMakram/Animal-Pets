/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SafessPipe } from './safess.pipe';

describe('Pipe: Safesse', () => {
  it('create an instance', () => {
    let pipe = new SafessPipe();
    expect(pipe).toBeTruthy();
  });
});
