export interface WriteComment {
    ID: number;
    Description: string;
    CommentDateTime: Date;
    PostID: number;
    UserId: string;
    UserPhoto: string;
    UserName: string;
}
