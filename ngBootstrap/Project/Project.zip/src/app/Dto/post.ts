export interface Post {
    Description: string;
    UserName: string;
    PostDateTime: Date;
    postPhotos: string[];
}
