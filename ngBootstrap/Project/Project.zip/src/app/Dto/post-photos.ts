export interface PostPhotos {
    ID: number
    Image:string
    PostID: number
}
