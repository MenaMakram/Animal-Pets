import { Animals } from './animals';

describe('Animals', () => {
  it('should create an instance', () => {
    expect(new Animals()).toBeTruthy();
  });
});
