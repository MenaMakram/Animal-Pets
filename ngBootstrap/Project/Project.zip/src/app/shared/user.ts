export class User {
public Address:string
public Email: string
public FirstName:string
public Id:string
public LastName: string
public PhoneNumber: number
public Photo: string
public UserName: string
}
