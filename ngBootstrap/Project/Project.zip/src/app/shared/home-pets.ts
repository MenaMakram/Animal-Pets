import { User } from './user';
export class HomePets {
     public  ID:number
        public  Description:string
        public  AvailablePlace:number
        public  NumberOfRooms:number
        public  PriceForNight:number
        public HomePhotos:string []
        public  User:User
    }
