export class AnimalPhoto {
   ID: number;
   Image: string;
}
