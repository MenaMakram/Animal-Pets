export class HomePetsPhoto {
    ID: number;
    Photo: string;
}
