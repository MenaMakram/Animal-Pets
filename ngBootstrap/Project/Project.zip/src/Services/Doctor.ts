import {Clinic} from './Clinic';

export class Doctor {
  ID: number;
   HasClinic: boolean;
   Clinics: Clinic[];
}
